## Index

* [Hadoop](#hadoop)
* [HTML and CSS](#html-and-css)
* [JavaScript](#javascript)
* [Machine Learning](#machine-learning)
* [MySQL](#mysql)
* [PHP](#php)
* [Ruby](#ruby)
* [Selenium](#selenium)
* [Software Architecture](#software-architecture)
* [Wordpress](#wordpress)


### Hadoop

* [எளிய தமிழில் Big Data](https://freetamilebooks.com/ebooks/learn-bigdata-in-tamil)


### HTML and CSS

* [எளிய தமிழில் CSS](https://freetamilebooks.com/ebooks/learn-css-in-tamil/) - Kaniyam Foundation (PDF)
* [எளிய தமிழில் HTML](https://freetamilebooks.com/htmlbooks/html-book/Learn-HTML-in-Tamil.html)


### JavaScript

* [எளிய தமிழில் JavaScript](https://freetamilebooks.com/ebooks/learn-javascript-in-tamil/)


### MachineLearning

* [எளிய தமிழில் ML](https://freetamilebooks.com/ebooks/learn_machine_learning_in_tamil/)


### MySQL

* [எளிய தமிழில் MySQL ](https://freetamilebooks.com/ebooks/learn-mysql-in-tamil)
* [எளிய தமிழில் MySQL – பாகம் 2 ](https://freetamilebooks.com/ebooks/learn-mysql-in-tamil-part-2)


### PHP

* [எளிய தமிழில் PHP](https://freetamilebooks.com/ebooks/learn-php-in-tamil/)


### Ruby

* [எளிய இனிய கணினி மொழி Ruby](https://freetamilebooks.com/ebooks/learn-ruby-in-tamil/) - பிரியா சுந்தரமூர்த்தி (PDF)


### Selenium

* [எளிய தமிழில் Selenium](https://freetamilebooks.com/ebooks/learn-selenium-in-tamil/) - Nithya Durai (PDF)


### Software Architecture

* [எளிய தமிழில் Agile/Scrum](https://freetamilebooks.com/ebooks/learn-agine-scrum-in-tamil)


### WordPress

* [எளிய தமிழில் WordPress](https://freetamilebooks.com/ebooks/learn-wordpress-in-tamil/)
