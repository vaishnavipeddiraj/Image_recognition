### Index

* [C](#c)
* [HTML and CSS](#html-and-css)
* [JavaScript](#javascript)
* [Linux](#linux)
* [PHP](#php)


### C

* [C Proqramlaşdırma Dili](http://ilkaddimlar.com/ders/c-proqramlasdirma-dili)


### HTML and CSS

* [CSS](http://ilkaddimlar.com/ders/css)
* [HTML](http://ilkaddimlar.com/ders/html)


### JavaScript

* [JavaScript](http://ilkaddimlar.com/ders/javascript)


### Linux

* [Linux](http://ilkaddimlar.com/ders/linux)


### PHP

* [PHP](http://ilkaddimlar.com/ders/php)
