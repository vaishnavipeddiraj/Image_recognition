### Index

* [Новини та розробка](#новини-та-розробка)


### Новини та розробка

* [DOU Podcast](https://soundcloud.com/doupodcast) (Podcast)
* [Потестим в проді](https://podcasts.apple.com/ua/podcast/%D0%BF%D0%BE%D1%82%D0%B5%D1%81%D1%82%D0%B8%D0%BC-%D0%B2-%D0%BF%D1%80%D0%BE%D0%B4%D1%96/id1528104095) (Podcast)
