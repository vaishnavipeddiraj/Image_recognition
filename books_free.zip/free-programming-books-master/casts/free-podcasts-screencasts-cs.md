### Podcasty

* [Brus kódu](http://bruskodu.cz) - pro frontend vývojáře
* [CZpodcast](https://soundcloud.com/czpodcast-1)
* [DevMinutes](http://devminutes.cz)
* [Kafemlejnek.TV](https://kafemlejnek.tv)
* [Vzhůru dolů podcast](https://www.vzhurudolu.cz/podcast) - Robin Pokorný, Martin Michálek
